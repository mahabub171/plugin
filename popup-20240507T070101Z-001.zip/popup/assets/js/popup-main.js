;(function ($) {
  if(document.getElementById('enable_Enable').checked) {
   //checked = checked;
}else if(document.getElementById('enable_Disable').checked) {
  //Female radio button is checked
}
    jQuery(document).ready(function($){
    $('.head-color-field').wpColorPicker();
    $('.body-color-field').wpColorPicker();
});
})(jQuery);

;(function ($) {
jQuery(window).load(function()
{
    jQuery('#myModal').modal('show');
});
     
        // var id = document.getElementById('modalContactForm');
        // if( id && id.style.display == 'none'){
        //         id.style.display = 'block';
        // }
        // else{
        //      modalContactForm.style.display == 'none';   
        // }
        })(jQuery);

       
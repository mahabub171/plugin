<?php
/**
* Plugin Name: Popup
* Plugin URI: 
* Description: A popup setting.
* Version: 1.0 or whatever version of the plugin (pretty self explanatory)
* Author: Plugin Author's Name
* Author URI: Author's website
* License: A "Slug" license name e.g. GPL12
* Text-Domain: popup
* Domain Path: /languages/
*/
function popup_load_textdomain() {
    load_plugin_textdomain('popup',false, dirnamr( __FILE__ ) ."/languages");
}

function assets($screen){
  if('toplevel_page_popup' == $screen){
    wp_register_style('popup-css-minitoggle',plugin_dir_url( __FILE__ ) . "/assets/css/minitoggle.css" );
    // wp_enqueue_style( 'wpdocs-style', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css' );
    wp_enqueue_style( 'popup-css-minitoggle' );
    wp_enqueue_script( 'popup-minitoggle-js', plugin_dir_url( __FILE__ ) . "/assets/js/minitoggle.js", array( 'jquery' ), "1.0", true );
    wp_enqueue_script( 'popup-main-js', plugin_dir_url( __FILE__ ) . "/assets/js/popup-main.js", array( 'jquery' ), time(), true );
    wp_register_script('my_popup_script', plugin_dir_url( __FILE__ ) . "assets/js/popup.min.js", array('jquery'),'1.1', true);
wp_enqueue_script('my_popup_script');
wp_register_script('popup_script', plugin_dir_url( __FILE__ ) . "/assets/js/bootstrap.min.js", array('jquery'),'1.1', true);
wp_enqueue_script('popup_script');
  wp_enqueue_script( 'wpdocs-script', '//ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js', array(), null, true );
    wp_enqueue_script( 'wpdocs', '//maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js', array('jquery'), null, true );

  }
}
add_action('admin_enqueue_scripts','assets');


function plugin_admin_init() {
     //All callbacks must be valid names of functions, even if provided functions are blank
  
  register_setting( 'sd_option_group', 'enable', 'sd_callback_function_enable' );
  register_setting( 'sd_option_group', 'title', 'sd_callback_function_name' );
	register_setting( 'sd_option_group', 'description', 'sd_callback_function_email' );
	register_setting( 'sd_option_group', 'alignment', 'sd_callback_function_align' );
	register_setting( 'sd_option_group', 'ver_alignment', 'sd_callback_function_ver' );
	register_setting( 'sd_option_group', 'hor_alignment', 'sd_callback_function_hor' );
	register_setting( 'sd_option_group', 'border', 'sd_callback_function_bor' );
	register_setting( 'sd_option_group', 'head', 'sd_callback_function_head' );
	register_setting( 'sd_option_group', 'body', 'sd_callback_function_body' );
	register_setting( 'sd_option_group', 'toggle_button', 'sd_callback_function_toggle_button' );
}
add_action( 'admin_init', 'plugin_admin_init' );

function wpdocs_register_my_custom_menu_page() {
	add_menu_page(
		__( 'Custom Menu Title', 'popup' ),
		'Popup',
		'manage_options',
		'popup.php',
		'my_custom_menu_page',
		plugins_url( 'popup/images/pop-up.png' ),
		6
	);
}

add_action( 'admin_menu', 'wpdocs_register_my_custom_menu_page' );
function my_custom_menu_page(){
    
    $settings 	= get_option( 'sd_fields' );
	$align 		= array( 'Left', 'Center', 'Right' );
	$vartical 		= array( 'Top', 'Middle', 'Bottom' );
	$horizontal 		= array( 'Start', 'Center', 'End' );
?>
 <h2>Settings</h2>



<form method="post" action="options.php">
		<?php settings_fields( 'sd_option_group' ); ?>
		<table>
		    <tr>
		        <td>Popup:</td>
		        <td>
		             <div>
		                 <input type="radio" id="enable_Enable" name="enable" data-toggle="modal" data-target="#myModal" value="Enable" <?php checked( 'Enable', get_option( 'enable' ) ); ?>>
		                 <label for="enable_Enable">Enable</label>
		             </div>
		             <div>
		                 <input type="radio" id="enable_Disable" name="enable" value="Disable" <?php checked( 'Disable', get_option( 'enable' ) ); ?>>
		                 <label for="enable_Disable">Disable</label> 
		              </div>
		        </td>
		    </tr>
		    <tr>
				<!-- <td>Popup Enable:</td>
				<td><label class="toggle">
         <input name="toggle_button" class="toggle-input" type="checkbox" value="" >
         <span class="toggle-label" data-off="NO" data-on="YES"></span>
         <span class="toggle-handle"></span>
      </label></td>
		</tr><br><br><br> -->
		    <tr>
				<td>Border Size (between 0 and 15):</td>
				<td><input type="number" name="border" placeholder="Border pixel" value="<?php echo get_option( 'border' ); ?>" min="0" max="15" /></td>
			</tr>	
		    <tr>
				<td>Title:</td>
				<td><input type="text" name="title" placeholder="Popup Title" value="<?php echo get_option( 'title' ); ?>" /></td>
			</tr>
			<tr>
				<td>Description:</td>
				<td><textarea name="description" rows="2" cols="50" placeholder="Popup Description"><?php echo get_option( 'description' ); ?></textarea></td>
			</tr>
			<tr>
				<td>Bacground Color:</td>
				<td><input type="color" name="head" value="<?php echo get_option( 'head' ); ?>" class="head-color-field" data-default-color="#eeeeee" /></td>
			</tr>
			<tr>
				<td>Border Color:</td>
				<td><input type="color" name="body" value="<?php echo get_option( 'body' ); ?>" class="body-color-field" data-default-color="#effeff" /></td>
			</tr>
			<tr>
				<td>Text Alignment:</td>
				<td>
					<select name="alignment">
						<?php foreach ( $align as $team ){
						echo '<option value="' . $team . '" ' . selected( $team, get_option( 'alignment' ) ) . '>' . $team . '</option>';
						} ?>
					</select>
				</td>
			</tr>
			<tr>
				<td>Vertical Align:</td>
				<td>
					<select name="ver_alignment">
						<?php foreach ( $vartical as $team ){
						echo '<option value="' . $team . '" ' . selected( $team, get_option( 'ver_alignment' ) ) . '>' . $team . '</option>';
						} ?>
					</select>
				</td>
			</tr>
			<tr>
				<td>Horizontal Align:</td>
				<td>
					<select name="hor_alignment">
						<?php foreach ( $horizontal as $team ){
						echo '<option value="' . $team . '" ' . selected( $team, get_option( 'hor_alignment' ) ) . '>' . $team . '</option>';
						} ?>
					</select>
				</td>
			</tr>
			<tr>
				<td colspan="2"><?php echo submit_button(); ?></td>
			</tr>
		</table>
 
	</form>

<?php }


function display_function() {
	

	wp_enqueue_script( 'mypopup-js', plugin_dir_url( __FILE__ ) . "assets/js/mypopup.js", array( 'jquery' ), time(), true );
	wp_enqueue_script( 'wpdocs-script', '//ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js', array('jquery'), null, true );
    wp_enqueue_script( 'wpdocs', '//maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js', array('jquery'), null, true );
if(get_option('enable') == "Enable" ) {?>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<style>  
        .modal {
        	position: absolute;
        	top: <?php if (get_option('ver_alignment') == 'Top') echo '0px';elseif (get_option('ver_alignment') == 'Middle') echo '30%';else echo '68%';?>;
        	left: <?php if (get_option('hor_alignment') == 'Start') echo '-61%';elseif (get_option('hor_alignment') == 'Center') echo '0vw';else echo '60vw';?>	
 
        }
        .modal-content{
        	background-color:<?php echo get_option( 'head' ); ?>;
        }
        .modal-dialog {
        	position: relative;
            border: <?php echo get_option('border'); ?>px solid <?php echo get_option( 'body' ); ?>;
            border-radius: 2px;
        }
	    .modal-header{
            text-align: <?php echo get_option('alignment'); ?>
        }
        .modal-body{
            /*background-color: <?php echo get_option( 'body' ); ?>;*/
            text-align: <?php echo get_option('alignment'); ?>
        }

 @media only screen and (max-width: 1524px) {
  .modal {
        	left: <?php if (get_option('hor_alignment') == 'Start') echo '-61vw';elseif (get_option('hor_alignment') == 'Center') echo '0vw';else echo '60vw';?>	
 
        }
} 
@media only screen and (max-width:1424px) {
  .modal {
        	left: <?php if (get_option('hor_alignment') == 'Start') echo '-55vw';elseif (get_option('hor_alignment') == 'Center') echo '0vw';else echo '50vw';?>	
 
        }
}
@media only screen and (max-width:1224px) {
  .modal {
        	left: <?php if (get_option('hor_alignment') == 'Start') echo '-45vw';elseif (get_option('hor_alignment') == 'Center') echo '0vw';else echo '40vw';?>	
 
        }
}
@media only screen and (max-width:1024px) {
  .modal {
        	left: <?php if (get_option('hor_alignment') == 'Start') echo '-35vw';elseif (get_option('hor_alignment') == 'Center') echo '0vw';else echo '35vw';?>	
 
        }
}
@media only screen and (max-width:824px) {
  .modal {
        	left: <?php if (get_option('hor_alignment') == 'Start') echo '-25vw';elseif (get_option('hor_alignment') == 'Center') echo '0vw';else echo '20vw';?>	
 
        }
}
@media only screen and (max-width:924px) {
  .modal {
        	left: <?php if (get_option('hor_alignment') == 'Start') echo '-20vw';elseif (get_option('hor_alignment') == 'Center') echo '0vw';else echo '20vw';?>	
 
        }
}
 @media only screen and (max-width: 766px) {
  .modal {
        	left: <?php if (get_option('hor_alignment') == 'Start') echo '-1vw';elseif (get_option('hor_alignment') == 'Center') echo '0vw';else echo '60vw';?>	
 
        }
}
  </style>

	  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header" style="">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          
        </div>
        <div class="modal-body">
          <p><?php echo get_option( 'description' ); ?></p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  <script type="text/javascript">
		// jQuery(window).load(function()
		// {
		//     jQuery('#myModal').modal('show');
		// });
      
  </script>
 
<?php }
}
add_action( 'wp_footer', 'display_function' );
